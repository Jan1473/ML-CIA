
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split 

from sklearn.linear_model import LinearRegression

data=pd.read_excel(r"C:\Users\janan\Downloads\salaryfinal.xlsx")
print(data)
data.isnull().sum()
plt.scatter( data['experience'] ,data['salary'] )
plt.xlabel('Year of Exp')
plt.ylabel('Salary')
plt.show()
X = data.drop('salary',axis=1)
y = data['salary']
X_train , X_test , Y_train , Y_test = train_test_split(X,y,random_state=101,test_size=0.2)
X_train.shape , X_test.shape , Y_train.shape , Y_test.shape
lr = LinearRegression()
lr.fit(X_train, Y_train)
pred = lr.predict(X_test)
print(pred)
print(Y_test)

import pickle
pickle.dump(lr,open("mlmodel.pkl","wb"))
